$(document).ready(function() {
  console.log('Document Ready');
  bindListeners();
});



